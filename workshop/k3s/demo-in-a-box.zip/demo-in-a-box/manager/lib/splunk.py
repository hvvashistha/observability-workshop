import json
import pathlib
import sqlite3
import subprocess
import time
from datetime import datetime

import pandas as pd  # type: ignore
import streamlit as st  # type: ignore
import yaml  # type: ignore
from kubernetes import client, config  # type: ignore

year = datetime.now().year

VERSION = "3.0.0"
CAPTION = f"© {year} Splunk Inc. All rights reserved. **Demo-in-a-Box v{VERSION}**"


def sql_connection():
    con = sqlite3.connect("manager.sqlite3")
    con.row_factory = sqlite3.Row
    return con


def sql_table(con):
    cursorObj = con.cursor()
    cursorObj.execute(
        "CREATE TABLE if not exists collector(id integer PRIMARY KEY, realm, ingest_token, rum_token, hec_url, hec_token, splunk_index, instance, ingest_url, api_url)"
    )
    cursorObj.execute(
        "CREATE TABLE if not exists current_demo(id integer PRIMARY KEY, name, deployment, experiment)"
    )
    cursorObj.execute(
        "INSERT OR IGNORE INTO collector VALUES(1, 'realm', 'ingest_token', 'rum_token', 'hec_url', 'hec_token', 'splunk_index', 'instance', 'ingest_url', 'api_url')"
    )
    cursorObj.execute("INSERT OR IGNORE INTO current_demo VALUES(1, 'None', 'None', 'None')")
    con.commit()


con = sql_connection()
sql_table(con)


class DemoManager:

    def __init__(self):
        config.load_kube_config()

        self.v1 = client.CoreV1Api()

        if "collector_running" not in st.session_state:
            st.session_state.collector_running = False
        
        self.check_status(status="Running")

    def available_demos(self):
        demo_dict = []
        with open(f"{pathlib.Path().resolve()}/use-cases.yaml", "r") as yamlfile:
            demos = yaml.safe_load_all(yamlfile)

            for demo in demos:
                demo_dict.append(demo)

        return demo_dict
    
    def available_experiments(self):
        experiment_dict = []
        with open(f"{pathlib.Path().resolve()}/chaos-mesh.yaml", "r") as yamlfile:
            experiments = yaml.safe_load_all(yamlfile)

            for experiment in experiments:
                experiment_dict.append(experiment)

        return experiment_dict

    def update_helm_repo(self):
        if st.session_state.helm_repo_updated is False:
            try:
                result = subprocess.run(
                    ["helm", "repo", "update"],
                    check=True,
                    text=True,
                    capture_output=True,
                )
                return result.stdout, result.returncode
            except subprocess.CalledProcessError as e:
                return e.stderr, e.returncode
        else:
            return "Helm repo already updated!", 0

    def demo_status(self):
        demo_dict = {}

        pods = self.v1.list_namespaced_pod(namespace="default")
        
        for pod in pods.items:
            if "splunk-otel-collector" not in pod.metadata.labels.values():
                status = pod.status.phase
                container_status = pod.status.container_statuses[0]
                waiting_state = container_status.state.waiting

                if waiting_state is not None:
                    status = waiting_state.reason
            
                running_state = container_status.state.running
                if running_state is not None:
                    status = "Running"

                demo_dict[pod.metadata.name] = status

        st.session_state.demo_running = False if not demo_dict else True

        return demo_dict

    def check_status(self, status=""):
        df = pd.DataFrame(columns=["Namespace", "Name", "Status", "Pod IP"])

        pods = self.v1.list_namespaced_pod(namespace="default")

        for pod in pods.items:
            if pod.status.phase == status:
                if "splunk-otel-collector" in pod.metadata.labels.values():
                    st.session_state.collector_running = True
                    row = [pod.metadata.namespace, pod.metadata.name, pod.status.phase, pod.status.pod_ip]
                    df.loc[len(df.index)] = row

        if df.empty:
            st.session_state.collector_running = False

        return df

    def get_collector_config(self):
        con = sql_connection()
        cur = con.cursor()
        cur.execute("SELECT * FROM collector WHERE id = 1")
        return cur.fetchone()

    def save_collector_config(
        self, ingest_url, api_url, realm, ingest_token, rum_token, hec_url, hec_token, splunk_index, instance
    ):
        con = sql_connection()
        cur = con.cursor()

        try:
            cur.execute(
                "UPDATE collector SET realm = ?, ingest_token = ?, rum_token = ?, hec_url = ?, hec_token = ?, splunk_index = ?, instance = ?, ingest_url=?, api_url=? WHERE id = 1",
                (
                    realm,
                    ingest_token,
                    rum_token,
                    hec_url,
                    hec_token,
                    splunk_index,
                    instance,
                    ingest_url,
                    api_url,
                ),
            )
            con.commit()
            self.patch_collector_secrets(realm, rum_token)
            return "OpenTelemetry configuration saved!", 200
        except Exception:
            con.rollback()
            return "Failed to save configuration", 500
        finally:
            con.close()

    def start_collector(self):
        con = sql_connection()
        cur = con.cursor()
        cur.execute("SELECT * FROM collector WHERE id = 1")
        result = cur.fetchone()
        cur.execute("SELECT * FROM current_demo WHERE id = 1")
        current_demo = cur.fetchone()

        try:
            result = subprocess.run(
                [
                    "helm",
                    "install",
                    "splunk-otel-collector",
                    f"--set=splunkObservability.ingestUrl={result['ingest_url']}",
                    f"--set=splunkObservability.apiUrl={result['api_url']}",
                    f"--set=splunkObservability.realm={result['realm']}",
                    f"--set=splunkObservability.accessToken={result['ingest_token']}",
                    f"--set=clusterName={result['instance']}-k3s-cluster",
                    "--set=logsEngine=otel",
                    f"--set=environment={result['instance']}-{current_demo['name']}",
                    "--set=splunkObservability.profilingEnabled=true",
                    f"--set=splunkPlatform.endpoint={result['hec_url']}",
                    f"--set=splunkPlatform.token={result['hec_token']}",
                    f"--set=splunkPlatform.index={result['splunk_index']}",
                    "splunk-otel-collector-chart/splunk-otel-collector",
                    "-f",
                    f"{pathlib.Path().resolve()}/opentelemetry-collector/values.yaml",
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def stop_collector(self):
        try:
            result = subprocess.run(
                ["helm", "delete", "splunk-otel-collector", "-n", "default"],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    @st.fragment()
    def get_pod_logs(self, pod_name):
        try:
            logs = subprocess.run(
                ["kubectl", "logs", pod_name, "-n", "default", "--tail=150"],
                check=True,
                text=True,
                capture_output=True,
            )
            return logs.stdout, logs.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def get_agent_logs(self):
        pods = self.v1.list_namespaced_pod(namespace="default")
        for pod in pods.items:
            if "splunk-otel-collector" in pod.metadata.labels.values() and "otel-collector-agent" in pod.metadata.labels.values():
                name = pod.metadata.name

        return self.get_pod_logs(name)

    def patch_deployment_secrets(self, instance, current_demo):
        current_instance = instance + "-" + current_demo
        command1 = {
            "stringData": {
                "app": current_instance + "-store",
                "deployment": "deployment.environment=" + current_instance,
                "env": current_instance,
                "instance": current_instance
            }
        }
        try:
            result = subprocess.run(
                [
                    "kubectl",
                    "patch",
                    "secret",
                    "workshop-secret",
                    "-p %s" % str(json.dumps(command1)),
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def patch_collector_secrets(self, realm, rum_token):
        command1 = {
            "stringData": {
                "realm": realm,
                "rum_token": rum_token,
            }
        }
        try:
            result = subprocess.run(
                [
                    "kubectl",
                    "patch",
                    "secret",
                    "workshop-secret",
                    "-p %s" % str(json.dumps(command1)),
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def deploy_demo(self, name, deployment):
        if st.session_state.collector_running:
            st.toast("Stopping OpenTelemetry Collector...")
            self.stop_collector()
            time.sleep(5)
        try:
            deployment_file = (
                f"{pathlib.Path().resolve()}/deployments/{deployment}.yaml"
            )
            result = subprocess.run(
                ["kubectl", "apply", "-f", f"{deployment_file}"],
                check=True,
                text=True,
                capture_output=True,
            )

            if result.returncode == 0:
                con = sql_connection()
                cur = con.cursor()
                cur.execute(
                    "UPDATE current_demo SET name = ?, deployment = ? WHERE id = 1",
                    (name, deployment,),
                )
                con.commit()
            st.session_state.current_demo_is_none = False
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr

    def delete_demo(self, deployment):
        try:
            deployment_file = (
                f"{pathlib.Path().resolve()}/deployments/{deployment}.yaml"
            )
            result = subprocess.run(
                ["kubectl", "delete", "-f", f"{deployment_file}"],
                check=True,
                text=True,
                capture_output=True,
            )

            if result.returncode == 0:
                con = sql_connection()
                cur = con.cursor()
                cur.execute(
                    "UPDATE current_demo SET name = NULL WHERE id = 1",
                )
                con.commit()
            st.session_state.current_demo_is_none = True
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def current_demo(self):
        con = sql_connection()
        cur = con.cursor()
        cur.execute("SELECT name, deployment FROM current_demo WHERE id = 1")
        return cur.fetchone()

    def current_experiment(self):
        con = sql_connection()
        cur = con.cursor()
        cur.execute("SELECT experiment FROM current_demo WHERE id = 1")
        return cur.fetchone()

    def update_current_demo(self, name, deployment):
        con = sql_connection()
        cur = con.cursor()
        cur.execute(
            "UPDATE current_demo SET name = ?, deployment = ? WHERE id = 1",
            (name, deployment, ),
        )
        con.commit()


def page_header(title, is_home=False):
    st.set_page_config(
        page_title=f"{title} - Demo-in-a-Box",
        page_icon=None,
        layout="wide",
        initial_sidebar_state="auto",
        menu_items={"About": f"**Demo in a Box - Version {VERSION}**"},
    )

    # with open( "app/style.css" ) as css:
    #    st.markdown( f'<style>{css.read()}</style>' , unsafe_allow_html= True)

    st.image("images/splunk-logo-white.png", width=130)
    st.caption(CAPTION)

    menu = st.popover("🧭 Menu")

    menu.page_link(
    "manager-ui.py", 
    label="Demonstration Use Cases", 
    icon="💼", 
    use_container_width=True
    )

    menu.page_link(
        "pages/collector.py",
        label="Manage OpenTelemetry Collector",
        icon="🔭",
        use_container_width=True
    )

    menu.page_link(
        "pages/status.py",
        label="Demonstration Status",
        icon="ℹ️",
        use_container_width=True
    )

    #menu.page_link(
    #    "pages/chaos.py",
    #    label="Chaos Mesh Experiments",
    #    icon="⚡",
    #    use_container_width=True
    #)
