# DIAB Manager

## Inspect Kubernetes secrets

``` bash
kubectl get secret workshop-secret -o json | jq '.data | map_values(@base64d)'
```

## Restart DIAB Manager services

``` bash
sudo systemctl restart diab-manager-api
sudo systemctl restart diab-manager-ui
```

## Secrets to be used in the YAML deployment files

``` ini
instance = 'instance-name' - 'current running demo' e.g. rwc-frontend
development = 'development.environment=instance name' - 'current running demo' e.g. rwc-frontend-store
app = 'instance name' - 'current running demo' - 'store' e.g. rwc-frontend-store (RUM)
```
