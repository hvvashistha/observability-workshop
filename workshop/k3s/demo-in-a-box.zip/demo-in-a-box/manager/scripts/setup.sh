#!/bin/bash -x
PWD=`pwd`
python3 -m venv venv
echo $PWD
activate () {
    . $PWD/venv/bin/activate
}
activate
pip3 install -r requirements.txt --upgrade
