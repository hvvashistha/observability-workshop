# List of changes to demo in a box**

## November 3

### Demo Changes

* Attempting to stop all running demo's when stopping the Collector
* Updated *Otel-base.yaml* to remove *sf_metric* send to O11Y Ingest
* Before collector is started deploy both mySql and Redis to the host
* Added both mySql and Redis to the collector config to collect metrics
* Running a new cartservice that uses Redis and mySql for NoSQL & db
  related contend demos
* Updated App.py & demos.py to fetch ip's & node names for mySql & Redis0
* Version updated to 1.2

## 12-July-2022

Release 1
