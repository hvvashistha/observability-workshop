from enum import Enum

class AgentStatus(Enum):
  UP=1
  DOWN=2
  STARTING=3