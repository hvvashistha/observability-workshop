from enum import Enum

class ServiceStatus(Enum):
  UP=1
  DOWN=2
  STARTING=3