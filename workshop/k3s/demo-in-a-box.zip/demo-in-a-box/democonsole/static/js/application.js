$(document).ready(function(){
  //connect to the socket server.
  var socket = io.connect('http://' + document.domain + ':' + location.port + '/connection');
  var txt_received = [];

  //receive details from server
  socket.on('update', function(msg) {
      console.log("Received update" + msg.update);
      if (txt_received.length >= 10){
        txt_received.shift()
      }            
      txt_received.push(msg.update);
      txt = '';
      for (var i = 0; i < txt_received.length; i++){
          txt = txt + '<p class="text-white">' + txt_received[i].toString() + '</p>';
      }
      //$('#log').html(txt);
  });

  socket.on('setConfig', function(msg) {
    $('#inputRealm').val(msg.realm)
    $('#inputAccessToken').val(msg.accessToken)
    $('#inputRumAccessToken').val(msg.rumAccessToken)
    $('#inputEnvironment').val(msg.environment)
    $('#inputHECUrl').val(msg.HECUrl)
    $('#inputHECToken').val(msg.HECToken)
    $('#inputLoadgenLocation').val(msg.accessToken)    
  });

  socket.on('showConfig', function(msg) {
    //$('#showConfig').removeClass('disabled')
    //$('#showDemos').addClass('disabled')
    $('#config').removeAttr("hidden")
    $('#demos').attr("hidden", "")
    $('#btnStopCollector').attr("hidden", "")
    $('#spinStoppingCollector').attr("hidden", "")
    $('#spinStartingCollector').attr("hidden", "")
    // console.log(msg.status)
    if (msg.status != 'starting') {
       $('#btnSaveConfig').removeClass("disabled")
       $('#spinStartingCollector').attr("hidden", "")
     } else {
       $('#btnSaveConfig').addClass("disabled")
       $('#spinStartingCollector').removeAttr("hidden")
     }
  });

  socket.on('showDemos', function() {
    //$('#showConfig').removeClass('disabled')
    //$('#showDemos').addClass('disabled')
    $('#config').attr("hidden", "")
    $('#demos').removeAttr("hidden")
    $('#btnStopCollector').removeAttr("hidden")
    $('#btnStopCollector').removeClass("disabled")
    $('#spinStoppingCollector').attr("hidden", "")
    $('#spinStartingCollector').attr("hidden", "")
  });

  socket.on('debugInfo', function(msg) {
    $('#log'.html(msg.html))
  })

  socket.on('backendDemo', function(msg) {
    if (msg.status == 'up') {
      $('#btnBackend').removeClass('btn-warning')
      $('#btnBackend').removeClass('btn-danger')
      $('#btnBackend').addClass('btn-success')
      $('#btnBackend').html('Stop Demo')
     } else {
      $('#btnBackend').removeClass('btn-warning')
      $('#btnBackend').removeClass('btn-success')
      $('#btnBackend').addClass('btn-danger')
      $('#btnBackend').html('Start Demo')
     }
  });

  socket.on('frontendDemo', function(msg) {
    if (msg.status == 'up') {
      $('#btnFrontend').removeClass('btn-warning')
      $('#btnFrontend').removeClass('btn-danger')
      $('#btnFrontend').addClass('btn-success')
      $('#btnFrontend').text('Stop Demo')
    } else {
      $('#btnFrontend').removeClass('btn-warning')
      $('#btnFrontend').removeClass('btn-success')
      $('#btnFrontend').addClass('btn-danger')
      $('#btnFrontend').text('Start Demo')
    }
  });
 
  socket.on('profilingDemo', function(msg) {
    if (msg.status == 'up') {
      $('#btnProfile').removeClass('btn-warning')
      $('#btnProfile').removeClass('btn-danger')
      $('#btnProfile').addClass('btn-success')
      $('#btnProfile').text('Stop Demo')
    } else {
      $('#btnProfile').removeClass('btn-warning')
      $('#btnProfile').removeClass('btn-success')
      $('#btnProfile').addClass('btn-danger')
      $('#btnProfile').text('Start Demo')
    }
  });

  socket.on('astroDemo', function(msg) {
    if (msg.status == 'up') {
      $('#btnAstro').removeClass('btn-warning')
      $('#btnAsro').removeClass('btn-warning')
      $('#btnAstro').removeClass('btn-danger')
      $('#btnAstro').addClass('btn-success')
      $('#btnAstro').text('Stop Demo')
    } else {
      $('#btnAstro').removeClass('btn-warning')
      $('#btnAstro').removeClass('btn-success')
      $('#btnAstro').addClass('btn-danger')
      $('#btnAstro').text('Start Demo')
    }
  });

  socket.on('immDatagenDemo', function(msg) {
    if (msg.status == 'up') {
      $('#btnImmDatagen').removeClass('btn-warning')
      $('#btnImmDatagen').removeClass('btn-danger')
      $('#btnImmDatagen').addClass('btn-success')
      $('#btnImmDatagen').text('Stop Demo')
    } else {
      $('#btnImmDatagen').removeClass('btn-warning')
      $('#btnImmDatagen').removeClass('btn-success')
      $('#btnImmDatagen').addClass('btn-danger')
      $('#btnImmDatagen').text('Start Demo')
    }
  });

  $("#btnShowConfig").click(function() {
    $.getJSON('/showconfig', {}, function(data) {})
  });

  $("#btnBackend").click(function() {
    if ($("#btnBackend").text() == 'Start Demo') {
      $('#div-db').attr("hidden", "")
      $("#btnBackend").html('<span class="spinner-border spinner-border-sm"></span>&nbsp;Starting Demo...')
      $.getJSON('/startdemo', {'demo': 'backend'}, function(data) {
        $('#log').html('<p class="text-white">Backend demo starting...</p>')
      });
    }
    if ($("#btnBackend").text() == 'Stop Demo') {
      $('#div-db').removeAttr("hidden")
       $("#btnBackend").html('<span class="spinner-border spinner-border-sm"></span>&nbsp;Stopping Demo...')
      $.getJSON('/stopdemo', {'demo': 'backend'}, function(data) {
        $('#log').html('<p class="text-white">Backend demo stopping...</p>')
      });
    }
  });

  $("#btnBackendV1").click(function() {
    $.getJSON('/toggledemo', {'demo': 'backend', 'state': '1'}, function(data) {});
  });

  $("#btnBackendV2").click(function() {
    $.getJSON('/toggledemo', {'demo': 'backend', 'state': '2'}, function(data) {});
  });

  // $("#btnastroV1").click(function() {
  //   $.getJSON('/toggledemo', {'demo': 'astro', 'state': '1'}, function(data) {});
  // });

  // $("#btncastroV2").click(function() {
  //   $.getJSON('/toggledemo', {'demo': 'astro', 'state': '2'}, function(data) {});
  // });
  
  $("#btnFrontend").click(function() {
    if ($("#btnFrontend").text() == 'Start Demo') {
      $('#div-fep').attr("hidden","")
      $("#btnErrors").html('Remove Payment Errors')
      $("#btnFrontend").html('<span class="spinner-border spinner-border-sm"></span>&nbsp;Starting Demo...')
      $.getJSON('/startdemo', {'demo': 'frontend'}, function(data) {
        $('#log').html('<p class="text-white">Frontend demo starting...</p>')
      });
    }
    if ($("#btnFrontend").text() == 'Stop Demo') {
      $('#div-fep').removeAttr("hidden") 
      $("#btnErrors").removeAttr("hidden") 
      $("#btnFrontend").html('<span class="spinner-border spinner-border-sm"></span>&nbsp;Stopping Demo...')
      $.getJSON('/stopdemo', {'demo': 'frontend'}, function(data) {
        $('#log').html('<p class="text-white">Frontend demo stopping...</p>')
      });
    }
  });

  $("#btnFrontendDefault").click(function() {
    $("#btnErrors").html('Remove Payment Errors')
    $.getJSON('/toggledemo', {'demo': 'frontend', 'state': 'default'}, function(data) {});
  });

  $("#btnErrors").click(function() {
    if ($("#btnErrors").text() == 'Remove Payment Errors') {
      $("#btnErrors").attr("hidden","")
      $.getJSON('/toggledemo', {'demo': 'frontend', 'state': 'errors'}, function(data) {});
      $('#log').html('<p class="text-white">Removing payment errors - Add them again via the Default button...</p>')
    } 
 }); 
 
  $("#btnProfile").click(function() {
    if ($("#btnProfile").text() == 'Start Demo') {
      $('#div-fe').attr("hidden","")
      $("#btnProfileOff").html('Remove Slowness Adservice')
      $("#btnProfile").html('<span class="spinner-border spinner-border-sm"></span>&nbsp;Starting Demo...')
      $.getJSON('/startdemo', {'demo': 'profiling'}, function(data) {
        $('#log').html('<p class="text-white">Profile demo starting...</p>')
      });
    }
    if ($("#btnProfile").text() == 'Stop Demo') {
      $('#div-fe').removeAttr("hidden")
      $('#btnProfileOff').removeAttr("hidden")
      $("#btnProfileOff").addClass('active')
      $("#btnProfile").html('<span class="spinner-border spinner-border-sm"></span>&nbsp;Stopping Demo...')
      $.getJSON('/stopdemo', {'demo': 'profiling'}, function(data) {
        $('#log').html('<p class="text-white">Profile demo stopping...</p>')
      });
    }
  });
   
  $("#btnProfileOff").click(function() {
    if ($("#btnProfileOff").text() == 'Remove Slowness Adservice') {
      $("#btnProfileOff").attr("hidden","")
      $.getJSON('/toggledemo', {'demo': 'profiling', 'state': 'off'}, function(data) {
        $('#log').html('<p class="text-white">Removing Long delay from Adservice - Check for p99 after 5 mins!<br> Add it agin by pressing Default button </p>') 
      });
    } 
  });

  $("#btnProfileDefault").click(function() {   
    $('#btnProfileOff').removeAttr("hidden")
    $("#btnProfileOff").addClass('active')
    $.getJSON('/toggledemo', {'demo': 'profiling', 'state': 'default'}, function(data) {
      $('#log').html('<p class="text-white">Resetting Profile demo - Adding adservice delay... Wait 5 mins !</p>')  
      });
  });

  $("#btnAstro").click(function() {
    if ($("#btnAstro").text() == 'Start Demo') {
      $('#div-be').attr("hidden","")
      $("#btnAstro").html('<span class="spinner-border spinner-border-sm"></span>&nbsp;Starting Demo...')
      $.getJSON('/startdemo', {'demo': 'astro'}, function(data) {
        $('#log').html('<p class="text-white">Astronomy Shop demo starting...</p>')
      });
    }
    if ($("#btnAstro").text() == 'Stop Demo') {
      $('#div-be').removeAttr("hidden")
      $("#btnAstro").html('<span class="spinner-border spinner-border-sm"></span>&nbsp;Stopping Demo...')
      $.getJSON('/stopdemo', {'demo': 'astro'}, function(data) {
        $('#log').html('<p class="text-white">Astronomy Shop demo  stopping...</p>')
      });
    }
  });

  $("#btnSaveConfig").click(function() {
    $('#btnSaveConfig').addClass('disabled')
    $('#spinStartingCollector').removeAttr('hidden')
    realm = $("#inputRealm").val()
    accessToken = $("#inputAccessToken").val()
    rumAccessToken = $("#inputRumAccessToken").val()
    environment = $("#inputEnvironment").val()
    HECUrl = $("#inputHECUrl").val()
    HECToken = $("#inputHECToken").val()
    loadgenLocation = $("#inputLoadgenLocation").val()
    data = { realm: realm, accessToken: accessToken, rumAccessToken: rumAccessToken, environment: environment, HECUrl: HECUrl, HECToken: HECToken, loadgenLocation: loadgenLocation }
    $.post('/saveConfig', data, function(data) {})
    $.getJSON('/startCollector', {}, function(data) {})
    $('#log').html('<p class="text-white">Starting the collector...</p>')
    return "OK"
  });
  
  $("#btnStopCollector").click(function() {
    $('#btnStopCollector').addClass('disabled')
    $('#spinStoppingCollector').removeAttr('hidden')
    $.getJSON('/stopCollector', {}, function(data) {})
  });

});
