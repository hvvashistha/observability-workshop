import re
import socket
import subprocess

from agentstatus import AgentStatus
from demostatus import DemoStatus
from servicestatus import ServiceStatus


class Demos:

  kubectlOutput = ""

  def __init__(self):
    print('init demo-class')

  def updateStatus(self):
    self.kubectlOutput = self.getKubectlPods()
    return self.kubectlOutput

  def getKubectlPods(self):
    output = subprocess.run(['kubectl', 'get', 'po', '-o', 'wide'], capture_output=True)
    str = output.stdout.decode()
    return str

  def getAgentStatus(self):
    agentUp_testStarting = re.search(r'.*splunk-otel-collector.*', self.kubectlOutput, re.MULTILINE)
    agentUp_test1 = re.search(r'.*splunk-otel-collector-agent.*', self.kubectlOutput, re.MULTILINE)
    agentUp_test2 = re.search(r'.*splunk-otel-collector-k8s-cluster-receiver.*', self.kubectlOutput, re.MULTILINE)
    if (agentUp_testStarting == None):
      return AgentStatus.DOWN
    else:
      if (agentUp_test1 == None or agentUp_test2 == None):
        return AgentStatus.STARTING
      else:
        return AgentStatus.UP

  def anyDemosTerminating(self):
    terminating = re.search('.*Terminating.*', self.kubectlOutput, re.MULTILINE)
    if (terminating != None):
      return True
    else:
      return False

  def backendStatus(self):
    backendUp = re.search(r'^demoinabox-deployment(\S)+(\s)+1\/1.*', self.kubectlOutput, re.MULTILINE)
    if (backendUp != None):
      return DemoStatus.UP
    else:
      return DemoStatus.DOWN

  def frontendStatus(self):
    frontendUp = re.search(r'^rum-loadgen-deployment(\S)+(\s)+1\/1.*', self.kubectlOutput, re.MULTILINE)
    if (frontendUp != None):
      return DemoStatus.UP
    else:
      return DemoStatus.DOWN

  def profilingStatus(self):
    profilingUp = re.search(r'^profile-loadgen-deployment(\S)+(\s)+1\/1.*', self.kubectlOutput, re.MULTILINE)
    if (profilingUp != None):
      return DemoStatus.UP
    else:
      return DemoStatus.DOWN

  def astroStatus(self):
    astroUp = re.search(r'^opentelemetry-demo-loadgenerator(\S)+(\s)+1\/1.*', self.kubectlOutput, re.MULTILINE)
    if (astroUp != None):
      return DemoStatus.UP
    else:
      return DemoStatus.DOWN 
    
  def dbQueryStatus(self):
    dbQueryUp = re.search(r'^demoinabox-db-deployment(\S)+(\s)+1\/1.*', self.kubectlOutput, re.MULTILINE)
    if (dbQueryUp != None):
      return DemoStatus.UP
    else:
      return DemoStatus.DOWN    

  def getIPAddress(self):
    output = subprocess.run(['kubectl', 'get', 'svc'], capture_output=True)
    str = output.stdout.decode()
    svcAddress = re.search(r'xxx', self.kubectlOutput, re.MULTILINE)
    return '192.168.7.234'
  
  def getMyNodeName(self):
    # curl http://169.254.169.254/1.0/meta-data/local-hostname
    return socket.gethostname()

  def getMySQLIPAddress(self):
    retval = None
    ipaddress_regexp = re.compile ('\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')
    output = subprocess.run(['kubectl', 'get', 'pod','-o', 'wide'], capture_output=True)
    str = output.stdout.decode()
    match = re.search(r'mysql-(\S)+(\s)+1\/1.*.*',str)
    if (match != None):
      result = ipaddress_regexp.search( match.group(0))
      if result:
        retval = result.group(0)
        print ('mysql ip is:' + retval)   
    return retval    
  
  def getRedisIPAddress(self):
    retval = None
    ipaddress_regexp = re.compile ('\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')
    output = subprocess.run(['kubectl', 'get', 'pod','-o', 'wide'], capture_output=True)
    str = output.stdout.decode()
    match = re.search(r'redis-(\S)+(\s)+1\/1.*.*',str)
    if (match != None):
      result = ipaddress_regexp.search( match.group(0))
      if result:
        retval = result.group(0)
        print ('Redis ip is:' + retval)   
    return retval      
  
  def checkServicesRunning(self):
      output = subprocess.run(['kubectl', 'get', 'pod','-o', 'wide'], capture_output=True)
      str = output.stdout.decode()
      dbMysqlUp = re.search(r'^mysql(\S)+(\s)+1\/1.*', str, re.MULTILINE)
      dbRedisUp = re.search(r'^redis(\S)+(\s)+1\/1.*', str, re.MULTILINE)
      if (dbMysqlUp == None and dbRedisUp == None):
        return ServiceStatus.DOWN
      elif (dbMysqlUp == None or dbRedisUp == None):
        return ServiceStatus.STARTING
      elif (dbMysqlUp != None and dbRedisUp != None):
        return ServiceStatus.UP
      return ServiceStatus.DOWN #just a catch all should never be reached
      
