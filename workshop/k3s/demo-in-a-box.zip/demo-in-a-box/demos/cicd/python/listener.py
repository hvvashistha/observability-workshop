from flask import Flask, request
import json
import signalfx
import redis
import yaml
from pyaml_env import parse_config

# Load configuration file
#with open('config.yaml', 'r') as ymlfile:
    #cfg = yaml.safe_load(ymlfile)
cfg = parse_config('config.yaml')

app = Flask(__name__)

r = redis.Redis(host=cfg['redis']['host'], port=cfg['redis']['port'], db=cfg['redis']['db'], charset="utf-8", decode_responses=True)

endpoint = 'https://ingest.' + cfg['signalfx']['realm'] + '.signalfx.com'
sfx = signalfx.SignalFx(ingest_endpoint=endpoint).ingest(cfg['signalfx']['token'])

'''
@app.route('/healthz', methods=['POST'])
def health():
    sfx.send(
        counters=[{
            'metric': 'autorem-listener.heartbeat',
            'value': 1
          }])
    return "Healthz OK!\n"
'''

@app.route('/health', methods=['POST'])
def healthCheck():    
    sfx.send_event(
        event_type='AutoRem Health Check',
        properties={
            'status': 'OK'})
    return "Health Check OK!\n"

@app.route('/health/<string:username>', methods=['POST'])
def healthCheckWithUser(username):
    sfx.send_event(
        event_type='AutoRem User Health Check',
        properties={
            'status': 'OK',
            'user': username})
    return "User Health Check OK!\n" 

@app.route('/write', methods=['POST'])
def write():
    data = json.loads(request.data.decode('utf-8'))
    if ('messageBody' in data) and ('status' in data):
      if not (data['status'].lower()=='anomalous'):  
        # ..Do nothing.. the alert is back to normal
        return "OK\n"

      if not data['messageBody']:
        print('Empty message Body, returning..')
        return "Empty Message Body\n"  
        
      body = data['messageBody'].split(" ")
      if 'Rollback' == body[1]:
        username = body[3]
        r.set(username, 'rollback')
        sfx.send_event(
        event_type='Automated Rollback Initiated',
        properties={
            'user': username})
    return "OK\n"

@app.route('/write/<string:username>/<int:batchsize>', methods=['POST'])
def writeSize(username,batchsize):
    if batchsize > 30000:
      r.set(username, 'bcanary')
    else:
      r.set(username, 'gcanary')
    sfx.send_event(
        event_type='Canary push event',
        properties={
            'user': username})
    return "OK\n" 

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=6000)
    finally:
        sfx.stop()