#!/bin/bash

# TODO: Check if demo-in-a-box instance exists
# TODO: Make sure you are in this repo's directory
# TODO: Make sure we can access gitlab (could be off of vpn when running this)

# Make a temporary directory on your system
mkdir demos
cd demos
# Get current path, it will be the same in multipass
CURRPATH=$(pwd)

# Clone all of the repos needed
# Back-end demo (JAR file from this repo)
cp -r ../backend .
# Front-end demo (main and profiling)
git clone --branch pmrum-shop https://github.com/signalfx/microservices-demo.git
mv microservices-demo frontend
git clone --branch add_profiling https://github.com/breedx-splk/microservices-demo.git
mv microservices-demo profiling
# CICD (these files are local to not pull down all files from field-demos)
cp -r ../cicd .
# IMM Datagen
git clone https://github.com/signalfx/o11y-datagen

# Launch the instance
multipass launch -n demo-in-a-box -d 10G -m 12G -c2

# Mount the filesystem
multipass mount . demo-in-a-box

# TODO: Run command to copy all of the files into a permanent directory
multipass exec demo-in-a-box -- cp -r $CURRPATH /home/ubuntu

# Unmount the filesystem
multipass unmount demo-in-a-box

# Remove demos
cd ..
rm -rf demos

# Shell into the instance
multipass shell demo-in-a-box